Udacity Review append A.2 updated.

ALL the question was answered in the append "Udacity Reviews" in the last pages of this report.
Thank you.
